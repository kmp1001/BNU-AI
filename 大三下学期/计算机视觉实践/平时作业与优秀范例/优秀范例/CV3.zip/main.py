import cv2
import numpy as np
from collections import deque

from PIL import Image
from matplotlib import pyplot as plt


# def show_image(cv_image, mode: str, title: str):
#     if mode == 'bgr':
#         cv_mode = cv2.COLOR_BGR2RGB
#     elif mode == 'gray':
#         cv_mode = cv2.COLOR_GRAY2RGB
#     else:
#         raise ValueError('Mode does not exist!')
#     rgb_img = cv2.cvtColor(cv_image, cv_mode)
#     plt.imshow(rgb_img)
#     plt.axis("off")
#     if title is not None:
#         plt.title(title)
#     plt.show()

def show_image(cv_image, mode: str, title: str):
    cv2.imshow(title, cv_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def intersection_solve(puzzle_path: str, kernel_size: tuple, iterations: int):
    puzzle_image = cv2.imread(puzzle_path)

    show_image(puzzle_image, 'bgr', 'Original Image')

    gray_image = cv2.cvtColor(puzzle_image, cv2.COLOR_BGR2GRAY)
    threshold, mask = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    show_image(mask, 'bgr', 'Mask Image')

    contours, herarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)

    contour_image = [np.zeros_like(mask) for i in range(3)]
    process_image = [None for i in range(3)]
    small_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, kernel_size)

    for i in range(2):
        cv2.drawContours(contour_image[i], contours, i, 255, -1)
        process_image[i] = cv2.dilate(contour_image[i], kernel, iterations=iterations)
    process_image[2] = cv2.bitwise_and(process_image[0], process_image[1])

    process_image[2] = cv2.absdiff(process_image[2], cv2.bitwise_and(process_image[2],
                                                                     cv2.dilate(contour_image[0], small_kernel,
                                                                                iterations=2)))

    process_image[2] = cv2.absdiff(process_image[2], cv2.bitwise_and(process_image[2],
                                                                     cv2.dilate(contour_image[1], small_kernel,
                                                                                iterations=2)))

    contours, herarchy = cv2.findContours(process_image[2], cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)
    cv2.drawContours(puzzle_image, contours, 0, (0, 0, 255), -1)

    show_image(puzzle_image, 'bgr', 'Output Image')


def BFS(grid, start, end):
    queue = deque()
    queue.append((start, [start]))
    visited = set()
    visited.add(start)

    while queue:
        (current, path) = queue.popleft()
        if current == end:
            return path

        for direction in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
            next_point = (current[0] + direction[0], current[1] + direction[1])
            if (grid.shape[0] > next_point[0] >= 0 and
                    0 <= next_point[1] < grid.shape[1] and 0 == grid[next_point[0]][next_point[1]] and
                    next_point not in visited):
                queue.append((next_point, path + [next_point]))
                visited.add(next_point)
    return None


def BFS_solve(puzzle_path: str, start, end):
    puzzle_image = cv2.imread(puzzle_path)
    show_image(puzzle_image, 'bgr', 'Original Image')
    gray_image = cv2.cvtColor(puzzle_image, cv2.COLOR_BGR2GRAY)
    threshold, mask = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    path = BFS(mask, start, end)

    if path:
        for point in path:
            puzzle_image[point[0]][point[1]] = [0, 0, 255]

    show_image(puzzle_image, 'bgr', 'Output Image')


intersection_solve('Puzzle1.png', (5, 5), 15)
intersection_solve('Puzzle2.png', (5, 5), 5)
intersection_solve('Puzzle3.png', (5, 5), 7)
intersection_solve('Puzzle4.png', (5, 5), 7)
intersection_solve('Puzzle5.png', (3, 3), 3)
BFS_solve('Puzzle6.png', (7, 405), (1193, 390))
intersection_solve('Puzzle7.png', (3, 3), 6)
intersection_solve('Puzzle8.png', (3, 3), 8)
intersection_solve('Puzzle9.png', (5, 5), 10)
intersection_solve('Puzzle10.png', (3, 3), 12)
BFS_solve('PuzzleNotWork1.png', (61, 571), (710, 530))
BFS_solve('PuzzleNotWork2.png', (37, 380), (393, 373))

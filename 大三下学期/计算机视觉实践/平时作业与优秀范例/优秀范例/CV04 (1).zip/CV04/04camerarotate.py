#按p选关键帧
import cv2
import numpy as np
import pandas as pd

# 读取正确答案
with open("Answers.txt", "r") as f:
    answers = f.read().strip().split()
answers = [ord(answer) - ord('A') for answer in answers]  # A/B/C/D 转换为 0/1/2/3

# 题号分布
question_numbers = {
    0: [1, 2, 3, 4, 5, 16, 17, 18, 19, 20, 31, 32, 33, 34, 35, 46, 47, 48, 49, 50],
    6: [6, 7, 8, 9, 10, 21, 22, 23, 24, 25, 36, 37, 38, 39, 40],
    12: [11, 12, 13, 14, 15, 26, 27, 28, 29, 30, 41, 42, 43, 44, 45]
}
# 透视变换
def get_warped_image(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edged = cv2.Canny(blurred, 50, 150)

    # 找到轮廓
    contours, _ = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)

    for contour in contours:
        peri = cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, 0.02 * peri, True)

        if len(approx) == 4:  # 只处理四边形
            pts = approx.reshape(4, 2)

            # 按照左上、右上、右下、左下的顺序排序
            rect = np.zeros((4, 2), dtype="float32")
            s = pts.sum(axis=1)
            rect[0] = pts[np.argmin(s)]  # 左上
            rect[2] = pts[np.argmax(s)]  # 右下
            diff = np.diff(pts, axis=1)
            rect[1] = pts[np.argmin(diff)]  # 右上
            rect[3] = pts[np.argmax(diff)]  # 左下

            # 计算目标尺寸
            widthA = np.linalg.norm(rect[2] - rect[3])
            widthB = np.linalg.norm(rect[1] - rect[0])
            maxWidth = max(int(widthA), int(widthB))

            heightA = np.linalg.norm(rect[1] - rect[2])
            heightB = np.linalg.norm(rect[0] - rect[3])
            maxHeight = max(int(heightA), int(heightB))

            dst = np.array([[0, 0], [maxWidth - 1, 0], [maxWidth - 1, maxHeight - 1], [0, maxHeight - 1]], dtype="float32")
            M = cv2.getPerspectiveTransform(rect, dst)
            warped = cv2.warpPerspective(image, M, (maxWidth, maxHeight))

            return warped

    return None  # 没找到合适的轮廓
# 提取学号
def extract_student_id(region, thresh, image):
    student_id = ""
    x, y, w, h = region
    y = y + 10
    h = h - 8
    student_id_region = thresh[y:y + h, x:x + w]  # 提取学号区域
    h_img, w_img = student_id_region.shape
    col_width = w_img // 12  # 每列的宽度（12位学号）
    row_height = h_img // 10  # 每行的高度（0-9共10个数字）

    # 遍历每一列（12位学号）
    for col in range(12):
        col_region = student_id_region[:, col * col_width:(col + 1) * col_width]
        max_fill = 0
        selected_digit = 0
        # 遍历每一行（0-9）
        for row in range(10):
            row_region = col_region[row * row_height:(row + 1) * row_height, :]
            fill = cv2.countNonZero(row_region)
            if fill > max_fill:
                max_fill = fill
                selected_digit = row
        student_id += str(selected_digit)
        # 在图像中标出选中的数字
        center_x = x + (col * col_width) + (col_width // 2)
        center_y = y + (selected_digit * row_height) + (row_height // 2)
        cv2.putText(image, str(selected_digit), (center_x, center_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 2)

    return student_id

# 提取答案
def extract_answers(region, thresh, image):
    x, y, w, h = region
    x += 18
    w -= 25
    h -= 70
    answer_region_img = thresh[y:y + h, x:x + w]
    h_img, w_img = answer_region_img.shape
    col_width = w_img // 17
    row_height = h_img // 24

    extracted = []
    for row in range(24):
        if row in [0, 6, 12, 18]:  # 空白行
            continue
        for col in range(17):
            if col in [0, 5, 6, 11, 12]:  # 题号列
                continue

            # 提取当前选项的区域
            row_region = answer_region_img[row * row_height:(row + 1) * row_height,
                                             col * col_width:(col + 1) * col_width]
            fill = cv2.countNonZero(row_region)
            if fill < 500:  # 设定一个阈值，判断是否填涂
                continue

            # 计算填涂块的中心点
            center_x = x + col * col_width + col_width // 2
            center_y = y + row * row_height + row_height // 2

            # 确定选项 (A/B/C/D)
            if col < 5:
                option = col - 1
            elif col < 11:
                option = col - 7
            else:
                option = col - 13

            # 确定题号列
            question_col = 0 if col < 6 else (6 if col < 12 else 12)

            # 计算行索引
            question_index = row - (1 if row < 6 else (2 if row < 12 else (3 if row < 18 else 4)))
            if question_index < 0 or question_index >= len(question_numbers[question_col]):
                continue

            question_number = question_numbers[question_col][question_index]
            cv2.putText(image, chr(ord('A') + option), (center_x, center_y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 200, 0), 2)
            extracted.append((question_number, option, (center_x, center_y)))

    return extracted

# 计算得分
def calculate_score(extracted_answers, answers, image):
    score = 0
    for (question_number, selected_option, pos) in extracted_answers:
        correct_option = answers[question_number - 1]
        is_correct = (selected_option == correct_option)
        score += 2 if is_correct else 0
        color = (0, 255, 0) if is_correct else (0, 0, 255)
        mark = "yes" if is_correct else "no"
        cv2.putText(image, mark, (pos[0] + 20, pos[1]),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
    return score

# 记录成绩
def save_score_to_csv(student_id, score, csv_file="scores.csv"):
    try:
        df = pd.read_csv(csv_file, dtype={"Student ID": str})
    except FileNotFoundError:
        df = pd.DataFrame(columns=["Student ID", "Score"])

    student_id = str(student_id).strip()
    df["Student ID"] = df["Student ID"].astype(str).str.strip()
    idx = df.index[df["Student ID"] == student_id].tolist()

    if idx:
        df.at[idx[0], "Score"] = score
    else:
        df = pd.concat([df, pd.DataFrame([{"Student ID": student_id, "Score": score}])], ignore_index=True)

    df.to_csv(csv_file, index=False)

# 初始化摄像头
cap = cv2.VideoCapture(0)

print("预览中，按下 'p' 键截取当前帧进行识别，按 'q' 键退出。")

while True:
    ret, frame = cap.read()
    if not ret:
        break
    rotated_frame = cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)
    # 显示实时预览画面
    cv2.imshow("Answer Sheet Scanner", rotated_frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('p'):
        # 当按下 'p' 键，截取当前帧进行处理
        #frame = cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)
        warped_frame = get_warped_image(rotated_frame)
        if warped_frame is None:
            print("未检测到答题卡，请调整角度重试")
            continue

        # 预处理图像
        gray = cv2.cvtColor(warped_frame, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        _, thresh = cv2.threshold(blurred, 150, 255, cv2.THRESH_BINARY_INV)

        # 查找答题卡区域
        contours, _ = cv2.findContours(thresh, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        min_area = 10000
        filtered_contours = [cv2.boundingRect(c) for c in contours if cv2.contourArea(c) > min_area]

        if len(filtered_contours) >= 2:
            # 选择学号区域和答案区域
            rectangles = sorted(filtered_contours, key=lambda x: x[2] * x[3], reverse=True)
            student_id_region = rectangles[2]
            answer_region = rectangles[1]

            # 在画面中描绘边框
            cv2.rectangle(warped_frame, (student_id_region[0], student_id_region[1]),
                          (student_id_region[0] + student_id_region[2], student_id_region[1] + student_id_region[3]),
                          (0, 255, 255), 2)
            cv2.rectangle(warped_frame, (answer_region[0], answer_region[1]),
                          (answer_region[0] + answer_region[2], answer_region[1] + answer_region[3]),
                          (255, 0, 255), 2)

            # 提取学号和答案
            student_id = extract_student_id(student_id_region, thresh, warped_frame)
            extracted_answers = extract_answers(answer_region, thresh, warped_frame)

            # 计算得分
            score = calculate_score(extracted_answers, answers, warped_frame)

            # 标注学号和分数
            cv2.putText(warped_frame, f"ID: {student_id}", (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4)
            cv2.putText(warped_frame, f"Score: {score}", (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4)

            # 保存成绩
            save_score_to_csv(student_id, score)

        cv2.imshow("Processed Frame", warped_frame)

    elif key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
#实时识别
import cv2
import numpy as np
import pandas as pd

# 读取正确答案
with open("Answers.txt", "r") as f:
    answers = f.read().strip().split()
answers = [ord(answer) - ord('A') for answer in answers]  # A/B/C/D 转换为 0/1/2/3

# 题号分布
question_numbers = {
    0: [1, 2, 3, 4, 5, 16, 17, 18, 19, 20, 31, 32, 33, 34, 35, 46, 47, 48, 49, 50],
    6: [6, 7, 8, 9, 10, 21, 22, 23, 24, 25, 36, 37, 38, 39, 40],
    12: [11, 12, 13, 14, 15, 26, 27, 28, 29, 30, 41, 42, 43, 44, 45]
}

# 提取学号
def extract_student_id(region, thresh, image):
    student_id = ""
    x, y, w, h = region
    y = y + 10
    h = h - 8
    student_id_region = thresh[y:y + h, x:x + w]  # 提取学号区域
    h_img, w_img = student_id_region.shape
    col_width = w_img // 12  # 每列的宽度（12位学号）
    row_height = h_img // 10  # 每行的高度（0-9共10个数字）

    # 遍历每一列（12位学号）
    for col in range(12):
        col_region = student_id_region[:, col * col_width:(col + 1) * col_width]
        max_fill = 0
        selected_digit = 0
        # 遍历每一行（0-9）
        for row in range(10):
            row_region = col_region[row * row_height:(row + 1) * row_height, :]
            fill = cv2.countNonZero(row_region)
            if fill > max_fill:
                max_fill = fill
                selected_digit = row
        student_id += str(selected_digit)
        # 在图像中标出选中的数字
        center_x = x + (col * col_width) + (col_width // 2)
        center_y = y + (selected_digit * row_height) + (row_height // 2)
        cv2.putText(image, str(selected_digit), (center_x, center_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 2)

    return student_id

# 提取答案
def extract_answers(region, thresh, image):
    x, y, w, h = region
    x += 18
    w -= 25
    h -= 70
    answer_region_img = thresh[y:y + h, x:x + w]
    h_img, w_img = answer_region_img.shape
    col_width = w_img // 17
    row_height = h_img // 24

    extracted = []
    for row in range(24):
        if row in [0, 6, 12, 18]:  # 空白行
            continue
        for col in range(17):
            if col in [0, 5, 6, 11, 12]:  # 题号列
                continue

            # 提取当前选项的区域
            row_region = answer_region_img[row * row_height:(row + 1) * row_height,
                         col * col_width:(col + 1) * col_width]
            fill = cv2.countNonZero(row_region)
            #if fill < 500:  # 设定一个阈值，判断是否填涂
            #   continue
            threshold_fill = row_height * col_width * 0.2  # 设定填充比例阈值
            if fill < threshold_fill:
                continue
            # 计算填涂块的中心点
            center_x = x + col * col_width + col_width // 2
            center_y = y + row * row_height + row_height // 2

            # 确定选项 (A/B/C/D)
            if col < 5:
                option = col - 1
            elif col < 11:
                option = col - 7
            else:
                option = col - 13

            # 确定题号列
            question_col = 0 if col < 6 else (6 if col < 12 else 12)

            # 计算行索引
            question_index = row - (1 if row < 6 else (2 if row < 12 else (3 if row < 18 else 4)))
            if question_index < 0 or question_index >= len(question_numbers[question_col]):
                continue

            question_number = question_numbers[question_col][question_index]
            cv2.putText(image, chr(ord('A') + option), (center_x, center_y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 200, 0), 2)
            extracted.append((question_number, option, (center_x, center_y)))

    return extracted

# 计算得分
def calculate_score(extracted_answers, answers, image):  # 关键修改点
    score = 0
    for (question_number, selected_option, pos) in extracted_answers:
        correct_option = answers[question_number - 1]
        is_correct = (selected_option == correct_option)
        score += 2 if is_correct else 0
        color = (0, 255, 0) if is_correct else (0, 0, 255)
        mark = "yes" if is_correct else "no"
        cv2.putText(image, mark, (pos[0] + 20, pos[1]),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
    return score

# 记录成绩
def save_score_to_csv(student_id, score, csv_file="scores.csv"):
    try:
        df = pd.read_csv(csv_file, dtype={"Student ID": str})
    except FileNotFoundError:
        df = pd.DataFrame(columns=["Student ID", "Score"])

    student_id = str(student_id).strip()
    df["Student ID"] = df["Student ID"].astype(str).str.strip()
    idx = df.index[df["Student ID"] == student_id].tolist()

    if idx:
        df.at[idx[0], "Score"] = score
    else:
        df = pd.concat([df, pd.DataFrame([{"Student ID": student_id, "Score": score}])], ignore_index=True)

    df.to_csv(csv_file, index=False)

# 初始化摄像头
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break
    frame = cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)

    # 图像处理
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blurred, 150, 255, cv2.THRESH_BINARY_INV)

    # 查找答题卡轮廓
    contours, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    min_area = 800
    filtered_contours = [contour for contour in contours if cv2.contourArea(contour) > min_area]

    if len(filtered_contours) >= 2:
        # 找到学号区域和答案区域
        rectangles = [cv2.boundingRect(contour) for contour in filtered_contours]
        rectangles.sort(key=lambda x: x[2] * x[3], reverse=True)

        student_id_region = rectangles[2]
        answer_region = rectangles[1]

        # 在画面中描绘边框
        cv2.rectangle(frame, (student_id_region[0], student_id_region[1]),
                      (student_id_region[0] + student_id_region[2], student_id_region[1] + student_id_region[3]),
                      (0, 255, 255), 2)  # 黄色边框表示学号区
        cv2.rectangle(frame, (answer_region[0], answer_region[1]),
                      (answer_region[0] + answer_region[2], answer_region[1] + answer_region[3]),
                      (255, 0, 255), 2)  # 紫色边框表示答案区

        # 提取学号和答案
        student_id = extract_student_id(student_id_region, thresh, frame)
        extracted_answers = extract_answers(answer_region, thresh, frame)

        # 计算得分
        score = calculate_score(extracted_answers, answers, frame)

        # 在图像上标注学号和分数
        cv2.putText(frame, f"ID: {student_id}", (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4)
        cv2.putText(frame, f"Score: {score}", (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4)

        # 保存成绩到CSV文件
        save_score_to_csv(student_id, score)

    # 显示图像
    cv2.imshow("Answer Sheet Scanner", frame)

    # 按下 'q' 键退出
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 释放摄像头并关闭窗口
cap.release()
cv2.destroyAllWindows()

import cv2
import numpy as np
import time
import os

def show(name, img):
    cv2.imshow(name, img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def crop_black_border(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    x, y, w, h = cv2.boundingRect(contours[0])
    return img[y:y + h, x:x + w]

def stitch_images(img_left, img_right):
    MIN = 4
    FLANN_INDEX_KDTREE = 0

    # 缩放右图到与左图相同高度
    h1 = img_left.shape[0]
    h2, w2 = img_right.shape[:2]
    scale = h1 / h2
    img_right = cv2.resize(img_right, (int(w2 * scale), h1))

    # SIFT 特征点提取
    sift = cv2.SIFT_create()
    kp1, descrip1 = sift.detectAndCompute(img_left, None)
    kp2, descrip2 = sift.detectAndCompute(img_right, None)

    indexParams = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    searchParams = dict(checks=50)
    flann = cv2.FlannBasedMatcher(indexParams, searchParams)
    matches = flann.knnMatch(descrip1, descrip2, k=2)

    good = []
    for m, n in matches:
        if m.distance < 0.75 * n.distance:
            good.append(m)

    if len(good) <= MIN:
        print("匹配点数不足")
        return img_left

    src_pts = np.float32([kp1[m.queryIdx].pt for m in good])
    dst_pts = np.float32([kp2[m.trainIdx].pt for m in good])
    M, _ = cv2.estimateAffinePartial2D(dst_pts, src_pts)
    warpImg = cv2.warpAffine(img_right, M, (img_left.shape[1] + img_right.shape[1], img_left.shape[0]))

    rows, cols = img_left.shape[:2]

    # 重叠区域融合
    for col in range(0, cols):
        if img_left[:, col].any() and warpImg[:, col].any():
            left = col
            break
    for col in range(cols - 1, 0, -1):
        if img_left[:, col].any() and warpImg[:, col].any():
            right = col
            break

    res = np.zeros([rows, cols, 3], np.uint8)
    for row in range(rows):
        for col in range(cols):
            if not img_left[row, col].any():
                res[row, col] = warpImg[row, col]
            elif not warpImg[row, col].any():
                res[row, col] = img_left[row, col]
            else:
                srcImgLen = float(abs(col - left))
                testImgLen = float(abs(col - right))
                alpha = srcImgLen / (srcImgLen + testImgLen + 1e-6)
                res[row, col] = np.clip(img_left[row, col] * (1 - alpha) + warpImg[row, col] * alpha, 0, 255)

    warpImg[0:img_left.shape[0], 0:img_left.shape[1]] = res
    return crop_black_border(warpImg)

# 主程序
starttime = time.time()

# 第一张图作为初始拼接图
base = cv2.imread('1.JPG')
for i in range(2, 15):
    filename = f"{i}.JPG"
    if not os.path.exists(filename):
        print(f"未找到文件 {filename}")
        continue
    next_img = cv2.imread(filename)
    base = stitch_images(base, next_img)
    print(f"完成拼接 {i - 1} 到 {i}.JPG")

# ✅ 显示 & 保存
show("Final Result", base)
cv2.imwrite("result.jpg", base)

print(f"总耗时：{time.time() - starttime:.2f} 秒")
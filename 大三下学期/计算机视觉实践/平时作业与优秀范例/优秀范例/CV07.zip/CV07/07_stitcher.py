import cv2
import os

# 展示图片函数
def cv_show(name, image):
    cv2.imshow(name, image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# 批量读取图像
image_files = [f"{i}.JPG" for i in range(1, 15)]  # 从1.JPG到14.JPG
images = []

for file in image_files:
    img = cv2.imread(file)
    if img is not None:
        images.append(img)
    else:
        print(f"无法读取图像：{file}")

# 创建 Stitcher 对象（OpenCV >= 4.x 推荐使用 cv2.Stitcher_create()）
stitcher = cv2.Stitcher_create()

# 执行拼接
print("开始拼接……")
status, stitched = stitcher.stitch(images)

# 检查拼接状态
if status == cv2.Stitcher_OK:
    print("拼接成功！")
    cv_show("Panorama", stitched)
    # 保存结果
    cv2.imwrite("stitched_result.jpg", stitched)
else:
    print(f"拼接失败，状态码: {status}")
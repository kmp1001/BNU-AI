import cv2
import numpy as np
import time

def show(name, img):
    cv2.imshow(name, img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def crop_black_border(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    x, y, w, h = cv2.boundingRect(contours[0])
    return img[y:y + h, x:x + w]

MIN = 4
FLANN_INDEX_KDTREE = 0
starttime = time.time()

img1 = cv2.imread('res1_13.jpg')  # 左图（query）
img2 = cv2.imread('14.JPG')  # 右图（train）

# 保留 imageA 尺寸，缩放 imageB 高度以对齐
imageA = img1
h1 = imageA.shape[0]
h2, w2 = img2.shape[:2]
scale = h1 / h2
imageB = cv2.resize(img2, (int(w2 * scale), h1))

sift = cv2.SIFT_create()
kp1, descrip1 = sift.detectAndCompute(imageA, None)
kp2, descrip2 = sift.detectAndCompute(imageB, None)

indexParams = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
searchParams = dict(checks=50)
flann = cv2.FlannBasedMatcher(indexParams, searchParams)
match = flann.knnMatch(descrip1, descrip2, k=2)

good = []
for i, (m, n) in enumerate(match):
    if m.distance < 0.75 * n.distance:
        good.append(m)

if len(good) > MIN:
    src_pts = np.float32([kp1[m.queryIdx].pt for m in good])
    ano_pts = np.float32([kp2[m.trainIdx].pt for m in good])

    # 仿射变换代替透视变换
    M, _ = cv2.estimateAffinePartial2D(ano_pts, src_pts)

    # 仿射变换图像（imageB 映射到 imageA 坐标系）
    warpImg = cv2.warpAffine(imageB, M, (imageA.shape[1] + imageB.shape[1], imageA.shape[0]))
    simple = time.time()
else:
    print("匹配点数不足")
    exit()

show('res', warpImg)

rows, cols = imageA.shape[:2]

for col in range(0, cols):
    if imageA[:, col].any() and warpImg[:, col].any():
        left = col
        break

for col in range(cols - 1, 0, -1):
    if imageA[:, col].any() and warpImg[:, col].any():
        right = col
        break

res = np.zeros([rows, cols, 3], np.uint8)
for row in range(0, rows):
    for col in range(0, cols):
        if not imageA[row, col].any():
            res[row, col] = warpImg[row, col]
        elif not warpImg[row, col].any():
            res[row, col] = imageA[row, col]
        else:
            srcImgLen = float(abs(col - left))
            testImgLen = float(abs(col - right))
            alpha = srcImgLen / (srcImgLen + testImgLen + 1e-6)
            res[row, col] = np.clip(imageA[row, col] * (1 - alpha) + warpImg[row, col] * alpha, 0, 255)

warpImg[0:imageA.shape[0], 0:imageA.shape[1]] = res

# ✅ 裁剪黑边
warpImg = crop_black_border(warpImg)

# ✅ 显示 & 保存
show('res', warpImg)
cv2.imwrite("res1_14.jpg", warpImg)

final = time.time()
print(f"耗时：{final - starttime:.2f} 秒")
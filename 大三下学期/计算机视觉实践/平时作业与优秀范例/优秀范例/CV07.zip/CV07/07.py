import cv2 as cv
import numpy as np


def sift_keypoints_detect(image):
    gray_image = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
    sift = cv.SIFT_create()
    keypoints, features = sift.detectAndCompute(gray_image, None)
    return cv.drawKeypoints(gray_image, keypoints, None, flags=cv.DRAW_MATCHES_FLAGS_NOT_DRAW_SINGLE_POINTS), keypoints, features


def get_feature_point_ensemble(features1, features2):
    bf = cv.BFMatcher()
    matches = bf.knnMatch(features1, features2, k=2)
    good = []
    for m, n in matches:
        if m.distance < 0.6 * n.distance:
            good.append(m)
    return good


def Panorama_stitching(image_right, image_left):
    _, kp_right, feat_right = sift_keypoints_detect(image_right)
    _, kp_left, feat_left = sift_keypoints_detect(image_left)
    goodMatch = get_feature_point_ensemble(feat_right, feat_left)

    if len(goodMatch) < 4:
        print("匹配点不足")
        return image_left

    ptsR = np.float32([kp_right[m.queryIdx].pt for m in goodMatch]).reshape(-1, 1, 2)
    ptsL = np.float32([kp_left[m.trainIdx].pt for m in goodMatch]).reshape(-1, 1, 2)
    H, _ = cv.findHomography(ptsR, ptsL, cv.RANSAC, 4)

    # 计算 warp 后的边界范围（对两图一起）
    h1, w1 = image_left.shape[:2]
    h2, w2 = image_right.shape[:2]

    # 四个角的坐标 warp 到同一空间
    pts_left = np.float32([[0, 0], [0, h1], [w1, h1], [w1, 0]]).reshape(-1, 1, 2)
    pts_right = np.float32([[0, 0], [0, h2], [w2, h2], [w2, 0]]).reshape(-1, 1, 2)
    pts_right_trans = cv.perspectiveTransform(pts_right, H)

    all_pts = np.concatenate((pts_left, pts_right_trans), axis=0)
    [xmin, ymin] = np.int32(all_pts.min(axis=0).ravel() - 0.5)
    [xmax, ymax] = np.int32(all_pts.max(axis=0).ravel() + 0.5)

    # 计算整体平移矩阵，使得warp图像不会有负坐标
    translation = [-xmin, -ymin]
    T = np.array([[1, 0, translation[0]], [0, 1, translation[1]], [0, 0, 1]])

    # warp 两张图像到新坐标空间
    result_right = cv.warpPerspective(image_right, T @ H, (xmax - xmin, ymax - ymin))
    result_left = np.zeros_like(result_right)
    result_left[translation[1]:translation[1] + h1, translation[0]:translation[0] + w1] = image_left

    # 创建掩膜避免黑边（简单融合）
    mask_left = (result_left > 0).astype(np.uint8)
    mask_right = (result_right > 0).astype(np.uint8)
    blend_mask = np.clip(mask_left + mask_right, 0, 1)

    # 简单融合：非重叠部分直接加，重叠部分取平均
    result = np.where(blend_mask == 2, (result_left // 2 + result_right // 2), result_left + result_right)

    return result.astype(np.uint8)


if __name__ == '__main__':
    image_paths = [f"{i}.JPG" for i in range(4, 10)]
    result = cv.imread(image_paths[0])
    result = cv.resize(result, None, fx=0.4, fy=0.24)

    for path in image_paths[1:]:
        image_right = cv.imread(path)
        h_result = result.shape[0]
        image_right = cv.resize(image_right, (int(image_right.shape[1] * h_result / image_right.shape[0]), h_result))

        result = Panorama_stitching(image_right, result)

    cv.imshow("最终全景图", result)
    cv.imwrite("全景图.jpg", result)
    cv.waitKey(0)
    cv.destroyAllWindows()